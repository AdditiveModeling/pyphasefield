# PyPhaseField

Python-based phase field software, built using numpy and pycalphad. 
Content will be added soon-TM, once i figure out this whole packaging thing

